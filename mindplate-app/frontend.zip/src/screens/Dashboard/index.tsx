import DashboardScreen from "./DashboardScreen";

export default DashboardScreen;
