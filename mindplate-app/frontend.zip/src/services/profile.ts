import api from "./api";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {jwtDecode} from "jwt-decode";

interface TokenPayload {
  user_id: number;
  exp: number;
}

async function getUserIdFromToken() {
  const token = await AsyncStorage.getItem("token");
  if (!token) throw new Error("No token found");

  const decoded = jwtDecode<TokenPayload>(token);
  return decoded.user_id;
}

export async function getProfile() {
  try {
    const token = await AsyncStorage.getItem("token");
    if (!token) return null;

    const response = await api.get("/profile/me", {
      headers: { Authorization: `Bearer ${token}` }
    });

    return {
      age: response.data.age,
      gender: response.data.gender,
      height: response.data.height,
      weight: response.data.weight,
      bmi: response.data.bmi,
      bmiCategory: response.data.bmi_category,
      mentalHealthCondition: response.data.mental_health_focus,
      origin: response.data.origin,                
      residence: response.data.residence, 
    };

  } catch (err) {
    return null;
  }
}

export async function createProfile(data: any) {
  const token = await AsyncStorage.getItem("token");
  return api.post("/profile/create", data, {
    headers: { Authorization: `Bearer ${token}` }
  });
}

export async function updateProfile(data:any) {
  const token = await AsyncStorage.getItem("token");
  return api.put("/profile/update", data, {
    headers: { Authorization: `Bearer ${token}` }
  });
}
